"""Fixed-scope serial/warp comparisons; every repeat is separately receipted."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from statistics import median
import time
from typing import Any

from pseudocube.accounting import Ledger,durable
from pseudocube.focus import A619,B619,Config,Tile
from pseudocube.gpu import GPUFocus,Matcher,Runtime

OPTIONS=(('serial',1),('warp',1),('warp',2),('warp',4))
POPULATIONS=('focus_u','focus_v','cartesian_opportunities','pairs_visited','valid_focused_candidates',
             'wide_constructions','group_survivors','local_survivors','genuine_cubes','noncube_reports','all_values')


def benchmark(runtime: Runtime, directory: Path, raw: dict[str,Any], a: GPUFocus, b: GPUFocus,
              source: dict[str,str]) -> dict[str,Any]:
    build=hashlib.sha256(json.dumps(source,sort_keys=True).encode()).hexdigest()
    ledger=Ledger(directory/'parallel-ledger',dict(pilot=raw,experiment='matching-parallelism-v1'),build)
    cases=[]
    for index,(numerator,denominator,width) in enumerate([(1,8,10**7),(1,2,3*10**7),(7,8,10**8),(5,7,5*10**7)]):
        region=min(index,2)
        config=Config(619,10**27+2*10**27*region//3,10**27+2*10**27*(region+1)//3,A619,B619)
        first=B619*numerator//denominator
        cases.append((config,Tile(first,first+width),'held-out' if index==3 else ('lower','middle','upper')[index]))
    ids=ledger.plan([dict(config=c.manifest(),**t.manifest(c),label=label) for c,t,label in cases])
    records=[]
    for (config,tile,label),work in zip(cases,ids):
        matchers=[Matcher(runtime,config,'byte',layout,target) for layout,target in OPTIONS]
        token=ledger.claim(work)
        try:reference=matchers[0].tile(tile,a,b)
        except Exception as exc:ledger.fail(work,token,repr(exc));raise
        reference.update(label=label,repeat=-1,work_id=work,attempt_id=token,purpose='validation-reference')
        ledger.commit(work,token,reference)
        # Rotate which variant runs first; focus generation stays in every timed run.
        for repeat in range(9):
            for index in [(repeat+j)%len(matchers) for j in range(len(matchers))]:
                matcher=matchers[index]
                token=ledger.begin_validation(work,f'{matcher.layout}-{matcher.blocks_per_sm}, repeat {repeat}')
                try:
                    row=matcher.tile(tile,a,b)
                    for key in POPULATIONS:
                        if row[key]!=reference[key]:raise ArithmeticError('parallelism mismatch: '+key)
                    row.update(label=label,repeat=repeat,work_id=work,attempt_id=token,purpose='validation-replay')
                except Exception as exc:
                    ledger.finish_validation(token,dict(status='FAIL',host_verified=False,error=repr(exc)))
                    ledger.quarantine(work,repr(exc));raise
                checkpoint=time.perf_counter();ledger.finish_validation(token,row)
                row['checkpoint_seconds']=time.perf_counter()-checkpoint;records.append(row)
        durable(directory/'parallel-progress.json',dict(status='IN_PROGRESS',records=records))
        print('Parallelism population comparisons passed: '+label,flush=True)
    summary=[]
    for config,tile,label in cases:
        baseline=[r for r in records if r['label']==label and r['layout']=='serial']
        for layout,target in OPTIONS:
            rows=[r for r in records if r['label']==label and r['layout']==layout and r['blocks_per_sm']==target]
            wall=median(r['end_to_end_seconds'] for r in rows);kernel=median(r['kernel_seconds'] for r in rows)
            summary.append(dict(label=label,layout=layout,blocks_per_sm=target,
                launch_blocks=rows[0]['launch_blocks'],warps_per_row=rows[0]['warps_per_row'],
                kernel_ms=1000*kernel,end_to_end_ms=1000*wall,
                min_end_to_end_ms=1000*min(r['end_to_end_seconds'] for r in rows),
                max_end_to_end_ms=1000*max(r['end_to_end_seconds'] for r in rows),
                enumeration_ms=1000*median(r['focus_enumeration_seconds'] for r in rows),
                checkpoint_ms=1000*median(r['checkpoint_seconds'] for r in rows),
                kernel_speedup=median(r['kernel_seconds'] for r in baseline)/kernel,
                end_to_end_speedup=median(r['end_to_end_seconds'] for r in baseline)/wall,
                candidates=rows[0]['valid_focused_candidates'],repeats=len(rows)))
    audit=ledger.audit();ledger.db.close()
    result=dict(status='PASS',experiment='matching-parallelism-v1',records=records,summary=summary,
                ledger=audit,expected_reference_tiles=4,expected_validation_replays=144,novel_production_coverage=0,
                timing='Nine interleaved repeats per layout per tile, full focus generation included; compilation and durable receipts separate.',
                occupancy='Launch geometry only. No measured active-warp occupancy.')
    durable(directory/'parallel-results.json',result)
    return result
