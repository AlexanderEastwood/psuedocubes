#!/usr/bin/env python3
"""Freeze and verify shared coverage receipts without interrupting GPU workers."""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import sqlite3
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pseudocube.accounting import durable
from pseudocube.multi import DEVICES, SharedFrontier, load_multi
from pseudocube.optimized import ledger_settings
from tools.run_production import frozen_build


def snapshot(state: Path, output: Path) -> None:
    output.mkdir(parents=True, exist_ok=False)
    coverage = output / 'coverage'
    coverage.mkdir()
    with sqlite3.connect((state / 'coverage/coverage.sqlite3').as_uri() + '?mode=ro', uri=True) as source:
        with sqlite3.connect(coverage / 'coverage.sqlite3') as target:
            source.backup(target)
    with sqlite3.connect(coverage / 'coverage.sqlite3') as db:
        rows = list(db.execute("SELECT receipt FROM leases WHERE state='committed'"))
    for (name,) in rows:
        if name.startswith('sqlite:'):
            continue
        destination = coverage / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(state / 'coverage' / name, destination)
    shutil.copy2(state / 'migration.json', output / 'migration.json')
    shutil.copytree(state / 'imported-single', output / 'imported-single')


def audit(state: Path, config: Path, build: str) -> dict[str, Any]:
    multi, raw, math = load_multi(config)
    active, width, profile = ledger_settings(state / 'coverage')
    if active != build:
        raise ValueError('audit release differs from active runtime')
    frontier = SharedFrontier(state / 'coverage', dict(multi=multi, production=raw, mathematics=math.manifest()),
                              build, math.B, width, DEVICES, profile=profile)
    try:
        return frontier.audit_shared()
    finally:
        frontier.db.close()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--state', type=Path, required=True)
    parser.add_argument('--snapshot', type=Path, required=True, help='new output directory for a consistent offline audit')
    args = parser.parse_args()
    snapshot(args.state.resolve(), args.snapshot.resolve())
    result = audit(args.snapshot.resolve(), ROOT / 'configs/pseudocube_619_multi.json', frozen_build())
    durable(args.snapshot / 'audit.json', result)
    print(__import__('json').dumps(result))


if __name__ == '__main__':
    main()
