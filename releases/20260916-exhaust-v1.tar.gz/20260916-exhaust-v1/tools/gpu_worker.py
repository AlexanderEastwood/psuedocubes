"""Private child of the persistent-budget pipeline; one GPU, explicit bounded tiles."""
from __future__ import annotations
import argparse
from contextlib import redirect_stdout
import fcntl
import hashlib
import io
from itertools import product
import json
from math import prod
import os
from pathlib import Path
import random
import resource
import shutil
import sqlite3
import subprocess
import sys
import time
from typing import Any

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import numpy as np
from pseudocube.accounting import Ledger, durable
from pseudocube.configuration import load
from pseudocube.focus import A619,B619,Config,Tile,enumerate_cpu,targeted_coordinates
from pseudocube.gpu import GPUFocus,Matcher,Runtime,WIDE
from pseudocube.oracle import local3
from tools.pseudocube_pipeline import build_manifest
from tools.parallel_benchmark import benchmark as parallel_benchmark, OPTIONS

N613=674441580981249129037406633


def same(actual: list[str], expected: set[int], case: str) -> None:
    if set(map(int,actual))!=expected or len(actual)!=len(expected):
        raise ArithmeticError('GPU/CPU complete-set disagreement: '+case)


def correctness(runtime: Runtime, directory: Path) -> tuple[list[dict[str,Any]],GPUFocus,GPUFocus]:
    rows=[];randomizer=random.Random(619003)
    cases=[(0,0,0,0),((1<<64)-1,(1<<64)-1,0,0),(0,0,(1<<64)-1,(1<<64)-1),(1<<32,1<<32,1,1)]
    cases += [tuple(randomizer.getrandbits(64) for _ in range(4)) for _ in range(2000)]
    data=runtime.cp.asarray(np.asarray(cases,dtype=np.uint64));out=runtime.cp.empty((len(cases),3),dtype=runtime.cp.uint64)
    kernel=runtime.compile(WIDE,'arithmetic')
    seconds=runtime.measured(kernel,((len(cases)+255)//256,),(data,out,np.uint64(len(cases))))
    for values,result in zip(cases,out.get()):
        a,b,c,d=values;low,high,borrow=map(int,result)
        if low+(high<<64)!=(a*b-c*d)%(1<<128) or borrow!=int(a*b<c*d):raise ArithmeticError('device limb smoke failed')
    rows.append(dict(case='GPU wide arithmetic',samples=len(cases),status='PASS',kernel_seconds=seconds))
    for p in (7,13,19,31):
        config=Config(p,0,100000,14*(19 if p>=19 else 1),9*(13 if p>=13 else 1)*(31 if p>=31 else 1))
        af,bf=config.focuses();a,b=GPUFocus(runtime,af),GPUFocus(runtime,bf)
        # Actual GPU focus windows, including a period boundary and exact sets.
        for focus,gpu in ((af,a),(bf,b)):
            low,high=max(0,focus.modulus-3),focus.modulus+7
            if set(map(int,gpu.window(low,high).get()))!=set(focus.window(low,high)):
                raise ArithmeticError('GPU focus window mismatch')
        expected={n for n in range(1,100001) if local3(n,p)}
        for variant in ('byte','packed','constant'):
            for layout,target in OPTIONS:
                matcher=Matcher(runtime,config,variant,layout,target)
                row=matcher.tile(Tile(0,config.B),a,b)
                same(row['all_values'],expected,f'complete p={p} {variant} {layout}-{target}')
                row['case']=f'complete p={p} {variant} {layout}-{target}';row['config']=config.manifest();rows.append(row)
        durable(directory/'gpu-correctness-progress.json',dict(status='IN_PROGRESS',cases=rows))
        print(f'Complete CPU/GPU sets passed through p={p}',flush=True)
        del a,b
    config=Config(7,0,100000,14,9);matcher=Matcher(runtime,config)
    af,bf=config.focuses();us=list(af.window(*config.u_interval(config.B-1)))
    # Force actual output overflow, then replay the exact work with enough space.
    us,vs=targeted_coordinates(config,1)
    try:matcher.coordinates(us,vs,cap=0)
    except OverflowError:rows.append(dict(case='forced GPU output overflow',status='PASS',expected_attempt_invalidated=True))
    else:raise ArithmeticError('output overflow not detected')
    rows.append(dict(case='overflow replay',**matcher.coordinates(us,vs)))
    # Invalidate an overflowing logical tile, split its coordinate domain, and
    # replay both children through the real kernels before committing either.
    af,bf=(GPUFocus(runtime,focus) for focus in config.focuses())
    whole=Tile(0,config.B)
    recovery=Ledger(directory/'overflow-ledger',config.manifest(),'gpu-overflow-test')
    work=recovery.plan([whole.manifest(config)])[0];token=recovery.claim(work)
    try:matcher.tile(whole,af,bf,output_cap=0)
    except OverflowError:recovery.fail(work,token,'forced output overflow')
    else:raise ArithmeticError('tile output overflow not detected')
    children=recovery.split(work);replayed=[]
    for child in children:
        scope=json.loads(recovery.db.execute('SELECT scope FROM work WHERE id=?',(child,)).fetchone()[0])
        token=recovery.claim(child)
        row=matcher.tile(Tile(int(scope['first']),int(scope['end'])),af,bf)
        recovery.commit(child,token,row);replayed.extend(row['all_values'])
    same(replayed,{n for n in range(1,100001) if local3(n,7)},'split overflow full-set replay')
    rows.append(dict(case='GPU overflowing tile invalidated, split and replayed',status='PASS',ledger=recovery.audit()))
    recovery.db.close()
    # A device table mutation must cause an integrity failure, not be discarded.
    bad=Matcher(runtime,Config(13,0,100000,14,117),'byte')
    fa,fb=bad.config.focuses()
    u=list(fa.window(bad.config.u_interval(0)[0],bad.config.u_interval(bad.config.B-1)[1]));v=list(fb.window(0,fb.modulus))
    bad.table.fill(1)
    try:bad.coordinates(u,v)
    except ArithmeticError:rows.append(dict(case='GPU table mutation',status='PASS',expected_integrity_failure=True))
    else:raise ArithmeticError('mutated table escaped CPU integrity checking')
    full=Config(619,10**27,3*10**27,A619,B619)
    start=time.perf_counter();a,b=(GPUFocus(runtime,focus) for focus in full.focuses())
    rows.append(dict(case='full focus preparation',status='PASS',wall_seconds=time.perf_counter()-start,
                     half_sizes=[a.half_sizes,b.half_sizes]))
    print('Full factored focuses prepared',flush=True)
    # High-value recovery is generated by GPU factored windows, not injected.
    for p,n in [(613,N613),(619,1000000007**3),(619,1000000009**3)]:
        config=Config(p,n-1,n,A619,B619)
        _,v=config.canonical(n);tile=Tile(max(0,v-5000000),min(config.B,v+5000001))
        for variant in ('byte','packed','constant'):
            row=Matcher(runtime,config,variant).tile(tile,a,b)
            same(row['all_values'],{n},f'high-value {n} {variant}')
            row['case']=f'targeted recovery p={p} {variant}';row['config']=config.manifest();rows.append(row)
        excluded=Config(p,n,n+1,A619,B619)
        row=Matcher(runtime,excluded,'byte').tile(tile,a,b)
        same(row['all_values'],set(),f'excluded lower endpoint {n}')
        row['case']='excluded lower endpoint';rows.append(row)
        durable(directory/'gpu-correctness-progress.json',dict(status='IN_PROGRESS',cases=rows))
        print(f'High-magnitude recovery and endpoint passed for p={p}, n={n}',flush=True)
    # Explicit CRT-derived noncube, constructed independently from chosen residues.
    moduli=[2,5,7,9,11,13];residues=[1,2,1,8,3,12];modulus=prod(moduli)
    n=sum(r*(modulus//q)*pow(modulus//q,-1,q) for q,r in zip(moduli,residues))%modulus
    if not local3(n,13):raise ArithmeticError('constructed CRT fixture invalid')
    config=Config(13,n-1,n,14,117);us,vs=targeted_coordinates(config,n)
    row=Matcher(runtime,config).coordinates(us,vs);same(row['all_values'],{n},'independently constructed CRT fixture')
    row['case']='independently constructed CRT fixture';row['config']=config.manifest();rows.append(row)
    durable(directory/'gpu-correctness.json',dict(status='PASS',cases=rows))
    return rows,a,b


def measurements(runtime: Runtime, directory: Path, raw: dict[str,Any], a: GPUFocus, b: GPUFocus) -> dict[str,Any]:
    source=build_manifest();build=hashlib.sha256(json.dumps(source,sort_keys=True).encode()).hexdigest()
    ledger=Ledger(directory/'pilot-ledger',raw,build)
    cases=[]
    for index,(numerator,denominator,width) in enumerate([(1,8,10**7),(1,2,3*10**7),(7,8,10**8),(5,7,5*10**7)]):
        region=min(index,2)
        lo=10**27+2*10**27*region//3;hi=10**27+2*10**27*(region+1)//3
        config=Config(619,lo,hi,A619,B619)
        first=B619*numerator//denominator
        tile=Tile(first,min(B619,first+width))
        cases.append((config,tile,'held-out' if index==3 else ('lower','middle','upper')[index]))
    scopes=[dict(config=c.manifest(),**t.manifest(c),label=label) for c,t,label in cases]
    ids=ledger.plan(scopes);records=[]
    for (config,tile,label),work in zip(cases,ids):
        reference=None
        for variant in ('byte','packed','constant'):
            matcher=Matcher(runtime,config,variant)
            for repeat in range(5):
                primary=reference is None
                token=ledger.claim(work) if primary else ledger.begin_validation(work,f'{variant} repeat {repeat}')
                try:
                    row=matcher.tile(tile,a,b)
                    row.update(label=label,repeat=repeat,configuration=config.manifest(),
                               work_id=work,attempt_id=token,purpose='primary' if primary else 'validation-replay')
                    if reference is not None:
                        for key in ('all_values','valid_focused_candidates','group_survivors','genuine_cubes'):
                            if row[key]!=reference[key]:raise ArithmeticError('A/B tile population disagreement: '+key)
                except Exception as exc:
                    if primary:ledger.fail(work,token,repr(exc))
                    else:
                        ledger.finish_validation(token,dict(status='FAIL',host_verified=False,error=repr(exc)))
                        ledger.quarantine(work,repr(exc))
                    raise
                checkpoint=time.perf_counter()
                if primary:
                    ledger.commit(work,token,row);reference=row
                else:ledger.finish_validation(token,row)
                row['checkpoint_seconds']=time.perf_counter()-checkpoint
                records.append(row)
        durable(directory/'benchmark-progress.json',dict(status='IN_PROGRESS',records=records))
    audited=ledger.audit()
    durable(directory/'pilot-ledger-audit.json',audited)
    return dict(status='PASS',records=records,ledger=audited,
                counted_tiles=len(ids),validation_replays=len(records)-len(ids),full_interval_complete=False)


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,required=True);parser.add_argument('--directory',type=Path,required=True)
    parser.add_argument('--seconds',type=float,required=True);parser.add_argument('--reservation',required=True)
    parser.add_argument('--parent-pid',type=int,required=True);args=parser.parse_args()
    if not 0<args.seconds<=570 or args.parent_pid!=os.getppid():raise ValueError('worker requires a bounded parent')
    authority=sqlite3.connect(ROOT/'artifacts/authority-budget/coverage.sqlite3')
    ticket=authority.execute('SELECT reserved,state FROM budget WHERE id=? AND kind=?',(args.reservation,'gpu')).fetchone();authority.close()
    if not ticket or ticket[1]!='held' or ticket[0]<args.seconds:raise ValueError('missing durable GPU budget reservation')
    raw,config=load(args.config);device=raw['pilot_budget']['device_uuid']
    if not device or os.environ.get('CUDA_VISIBLE_DEVICES')!=device:raise ValueError('single authorized allocation required')
    start=time.monotonic();result: dict[str,Any]=dict(status='FAIL',device_uuid=device)
    lock=Path('/tmp')/('pseudocube-'+device+'.lock')
    with lock.open('a') as stream:
        fcntl.flock(stream.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        running=subprocess.check_output(['nvidia-smi','-i',device,'--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
        if running:raise RuntimeError('authorized GPU is occupied; no jobs were stopped')
        try:
            runtime=Runtime(start+args.seconds,int(raw['pilot_budget']['max_device_memory_bytes']),
                            float(raw['pilot_budget']['max_device_memory_fraction']))
            if runtime.cp.cuda.runtime.getDeviceCount()!=1:raise RuntimeError('multi-device visibility rejected')
            log=io.StringIO()
            with redirect_stdout(log):runtime.cp.show_config()
            (args.directory/'cuda-toolchain.txt').write_text(log.getvalue())
            props=runtime.cp.cuda.runtime.getDeviceProperties(0)
            result.update(device_name=props['name'].decode(),sm_count=props['multiProcessorCount'],
                          cupy=runtime.cp.__version__,numpy=np.__version__,cuda_runtime=runtime.cp.cuda.runtime.runtimeGetVersion(),
                          device_memory_cap=runtime.cap,compute_sanitizer=shutil.which('compute-sanitizer'),nvcc=shutil.which('nvcc'),
                          compile_backend='CuPy RawKernel / NVRTC / C++17, explicit 64-bit limbs')
            tests,a,b=correctness(runtime,args.directory)
            result['correctness']=dict(status='PASS',cases=len(tests))
            result['measurements']=measurements(runtime,args.directory,raw,a,b)
            result['parallelism']=parallel_benchmark(runtime,args.directory,raw,a,b,build_manifest())
            result.update(status='PASS',compiles=runtime.compiles,peak_pool_bytes=runtime.peak_device,
                          maximum_host_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
        except Exception as exc:
            result['error']=repr(exc);durable(args.directory/'quarantine.json',result);raise
        finally:
            result['worker_wall_seconds']=time.monotonic()-start
            durable(args.directory/'gpu-results.json',result)
    print(json.dumps(dict(status='PASS',wall_seconds=time.monotonic()-start)),flush=True)


if __name__=='__main__':main()
