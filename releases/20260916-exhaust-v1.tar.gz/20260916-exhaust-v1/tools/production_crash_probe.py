#!/usr/bin/env python3
"""Crash only child processes created in a temporary test ledger; never a service/GPU."""
from __future__ import annotations
import argparse
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from typing import Any

from pseudocube.production import Frontier
import pseudocube.production as production
from pseudocube.accounting import durable


def child(directory: Path,stage: str) -> None:
    with (directory/'owner.lock').open('a') as owner:
        fcntl.flock(owner.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        db=Frontier(directory/'ledger',{'isolated_crash_probe':True},'probe',20,10)
        job=db.next_batch();assert job
        def ready() -> None:
            durable(directory/'ready.json',dict(pid=os.getpid(),stage=stage,work=job[0],attempt=job[1]))
            while True:time.sleep(1)
        if stage=='after-claim':ready()
        original=production.save_compressed
        def interrupted_save(path: Path,value: dict[str,Any]) -> str:
            sha=original(path,value);ready();return sha
        production.save_compressed=interrupted_save
        result=dict(status='PASS',host_verified=True,valid_focused_candidates=7,genuine_cubes=0,
                    cpu_confirmed_hits=[],subtile_scopes=[dict(first='0',end='10')])
        db.complete(*job,result)


def run(stage: str) -> dict[str,Any]:
    with tempfile.TemporaryDirectory(prefix='pseudocube-isolated-crash-') as temporary:
        directory=Path(temporary)
        process=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--child',str(directory),'--stage',stage])
        try:
            start=time.monotonic()
            while not (directory/'ready.json').exists():
                if process.poll() is not None or time.monotonic()-start>10:raise RuntimeError('isolated child failed to reach fault point')
                time.sleep(.02)
            marker=json.loads((directory/'ready.json').read_text())
            if marker['pid']!=process.pid:raise RuntimeError('unexpected child identity')
            # Only this Popen-created, CPU-only child is terminated.
            process.kill();process.wait(timeout=5)
            with (directory/'owner.lock').open('a') as owner:
                fcntl.flock(owner.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
                db=Frontier(directory/'ledger',{'isolated_crash_probe':True},'probe',20,10)
                if db.state()['cursor']!='0':raise ArithmeticError('uncommitted crash advanced coverage')
                recovered=db.recover_stopped_owner('Child '+str(process.pid)+' exited with '+str(process.returncode)+'; exclusive lock reacquired')
                job=db.next_batch();assert job
                result=dict(status='PASS',host_verified=True,valid_focused_candidates=7,genuine_cubes=0,
                            cpu_confirmed_hits=[],subtile_scopes=[dict(first='0',end='10')])
                db.complete(*job,result);audit=db.audit_production()
                if job[0]!=marker['work'] or job[1]==marker['attempt'] or audit['commits']!=1:
                    raise ArithmeticError('recovery identity/count failed')
                db.db.close()
                return dict(status='PASS',stage=stage,child_exit=process.returncode,recovered=recovered,audit=audit,
                            production_interrupted=False,gpu_used=False)
        finally:
            if process.poll() is None:process.kill();process.wait()


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--child',type=Path)
    parser.add_argument('--stage',choices=('after-claim','after-durable-output'))
    args=parser.parse_args()
    if args.child:
        if args.stage is None:raise ValueError('fault stage required')
        child(args.child,args.stage)
    else:print(json.dumps(dict(status='PASS',tests=[run(stage) for stage in ('after-claim','after-durable-output')]),indent=2))


if __name__=='__main__':main()
