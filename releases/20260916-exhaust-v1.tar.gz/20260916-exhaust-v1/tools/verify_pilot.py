#!/usr/bin/env python3
"""Read-only verification of a bounded pilot's receipts; not an arithmetic exhaustion proof."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
from typing import Any

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from review.verify_cube import verify


def audit(directory: Path, source_root: Path | None = None) -> dict[str,Any]:
    pipeline=json.loads((directory/'pipeline.json').read_text())
    if pipeline['stage_a']['status']!='PASS' or pipeline['stage_b']['status']!='PASS':
        raise ValueError('pipeline gate did not pass')
    manifest=json.loads((directory/'source-manifest.json').read_text())
    if hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()!=pipeline['build']:
        raise ValueError('build manifest identity mismatch')
    if source_root:
        for name,sha in manifest.items():
            if hashlib.sha256((source_root/name).read_bytes()).hexdigest()!=sha:
                raise ValueError('source mismatch: '+name)
    base=directory/'pilot-ledger'
    db=sqlite3.connect((base/'coverage.sqlite3').resolve().as_uri()+'?mode=ro',uri=True)
    db.row_factory=sqlite3.Row
    try:
        if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('database corruption')
        identity=db.execute("SELECT value FROM meta WHERE key='config'").fetchone()[0]
        work=list(db.execute('SELECT * FROM work'))
        if len(work)!=4 or any(row['state']!='committed' for row in work):raise ValueError('expected four committed pilot scopes')
        scopes=[json.loads(row['scope']) for row in work]
        for i,left in enumerate(scopes):
            for right in scopes[i+1:]:
                # Overlap requires overlap in BOTH x and canonical v.
                a,b=left['config'],right['config']
                x_overlap=max(int(a['lo_exclusive']),int(b['lo_exclusive']))<min(int(a['hi_inclusive']),int(b['hi_inclusive']))
                v_overlap=max(int(left['first']),int(right['first']))<min(int(left['end']),int(right['end']))
                if x_overlap and v_overlap:raise ValueError('overlapping pilot scopes')
        for row in work:
            data=(base/row['receipt']).read_bytes();receipt=json.loads(data)
            if hashlib.sha256(data).hexdigest()!=row['sha'] or receipt['config']!=identity or receipt['work_id']!=row['id'] or receipt['attempt']!=row['token'] or receipt['build']!=pipeline['build']:
                raise ValueError('invalid primary receipt')
            result=receipt['result']
            if result['status']!='PASS' or not result['host_verified']:raise ValueError('unverified primary')
            for n in result['cpu_confirmed_hits']:
                if not verify(int(n),619)['valid_pseudocube']:raise ValueError('invalid candidate')
        replay=list(db.execute('SELECT * FROM validations'))
        for row in replay:
            data=(base/row['receipt']).read_bytes();receipt=json.loads(data)
            if row['state']!='verified' or hashlib.sha256(data).hexdigest()!=row['sha'] or receipt['attempt']!=row['token'] or receipt['work_id']!=row['work_id'] or receipt['build']!=row['build'] or receipt['config']!=identity:
                raise ValueError('invalid replay receipt')
        if len(replay)!=56:raise ValueError('expected 56 separately recorded validation replays')
    finally:db.close()
    return dict(status='PASS',primary_tiles=len(work),validation_replays=len(replay),source_files_checked=len(manifest) if source_root else 0,
                claim='Artifact integrity and bounded ledger structure; not independent target-range arithmetic reproduction.')


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory',type=Path);parser.add_argument('--source-root',type=Path)
    args=parser.parse_args();print(json.dumps(audit(args.directory,args.source_root),indent=2))


if __name__=='__main__':main()
