#!/usr/bin/env python3
"""Run prerequisite gates and a budgeted pilot, then stop at Stage C."""
from __future__ import annotations
import argparse
from contextlib import redirect_stderr, redirect_stdout
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time
from typing import Any

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from pseudocube.accounting import Ledger, durable
from pseudocube.configuration import load


def build_manifest() -> dict[str,str]:
    paths=[*ROOT.glob('pseudocube/*.py'),*ROOT.glob('tools/*.py'),*ROOT.glob('review/*.py'),
           *ROOT.glob('review/*.c'),*ROOT.glob('kernels/*'),*ROOT.glob('tests/*.py'),ROOT/'search_cube.py']
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths) if p.is_file()}


def directory_bytes(path: Path) -> int:
    return sum(p.stat().st_size for p in path.rglob('*') if p.is_file())


def run_command(argv: list[str], out: Path, timeout: float = 120) -> dict[str,Any]:
    started=time.monotonic()
    with out.open('w') as stream:
        result=subprocess.run(argv,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout)
    row=dict(command=argv,exit_code=result.returncode,wall_seconds=time.monotonic()-started,log=str(out.relative_to(ROOT)))
    if result.returncode:raise RuntimeError(json.dumps(row))
    return row


def stage_a(directory: Path) -> dict[str,Any]:
    (ROOT/'build').mkdir(exist_ok=True)
    commands=[]
    for name in ('cube_count','cube_count_independent'):
        commands.append(run_command(['cc','-O3','-Wall','-Wextra',f'review/{name}.c','-o',f'build/{name}'],directory/f'build-{name}.log'))
    commands.append(run_command(['cc','-O2','-shared','-fPIC','review/wide.c','-o','build/wide.so'],directory/'build-wide.log'))
    commands.append(run_command([sys.executable,'-m','unittest','discover','-s','tests','-p','test_pseudocube_*.py','-v'],directory/'cpu-tests.log'))
    counts=[]
    for name in ('cube_count','cube_count_independent'):
        path=directory/f'{name}.json'
        commands.append(run_command([str(ROOT/'build'/name),'1000000001','1442249570','619'],path))
        counts.append(json.loads(path.read_text()))
    if not int(counts[0]['count'])==int(counts[1]['count'])==38322775:
        raise ArithmeticError('independent cube counts disagree; target GPU gate blocked')
    return dict(status='PASS',commands=commands,cube_counts=counts,
                scope='Complete bounded reference tests and targeted known-value recovery; no full historical replay.')


def gpu_stage(directory: Path, config_path: Path, raw: dict[str,Any], budget: Ledger, pilot_remaining: float) -> dict[str,Any]:
    allocation=raw['pilot_budget']['device_uuid']
    if platform.system()!='Linux' or allocation is None:
        return dict(status='BLOCKED_GPU',reason='Needs the authorized Linux Quad GPU allocation; CPU work completed.')
    existing=os.environ.get('CUDA_VISIBLE_DEVICES')
    if existing and existing!=allocation:
        raise ValueError('existing CUDA_VISIBLE_DEVICES allocation differs; do not override it')
    limits=raw['pilot_budget']
    used=budget.audit()['budget']
    remaining=float(limits['max_total_gpu_allocation_wall_seconds'])-sum(
        float(r['reserved'] if r['state']=='held' else r['charged']) for r in used if r['kind']=='gpu')
    if min(remaining,pilot_remaining)<=10:return dict(status='BUDGET_EXHAUSTED',reason='No aggregate GPU/pilot allocation time remains')
    allowance=min(remaining-2,pilot_remaining-2,570.0)
    reservation=budget.reserve('gpu',allowance,float(limits['max_total_gpu_allocation_wall_seconds']))
    env=dict(os.environ,CUDA_VISIBLE_DEVICES=allocation,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='2')
    start=time.monotonic();reason=None;process=None
    try:
        with (directory/'gpu-worker.log').open('w') as stream:
            process=subprocess.Popen([sys.executable,str(ROOT/'tools/gpu_worker.py'),'--config',str(config_path),
                '--directory',str(directory),'--seconds',str(allowance-3),'--reservation',reservation,
                '--parent-pid',str(os.getpid())],cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            while process.poll() is None:
                if time.monotonic()-start>=allowance-1:reason='BUDGET_EXHAUSTED'
                status=Path(f'/proc/{process.pid}/status')
                if status.exists():
                    for line in status.read_text().splitlines():
                        if line.startswith('VmRSS:') and int(line.split()[1])*1024>limits['max_host_working_memory_bytes']:
                            reason='HOST_MEMORY_CAP_EXCEEDED'
                if directory_bytes(ROOT/'artifacts')>limits['max_output_bytes']:reason='OUTPUT_CAP_EXCEEDED'
                if reason:
                    os.killpg(process.pid,signal.SIGTERM)
                    try:process.wait(timeout=.5)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid,signal.SIGKILL);process.wait()
                    break
                time.sleep(.1)
        elapsed=time.monotonic()-start
        row=dict(status=reason or ('PASS' if process.returncode==0 else 'FAIL'),exit_code=process.returncode,
                 allocation_wall_seconds=elapsed,reservation=reservation,log=str((directory/'gpu-worker.log').relative_to(ROOT)))
        if (directory/'gpu-results.json').exists():row['results']=json.loads((directory/'gpu-results.json').read_text())
        return row
    finally:
        if process is not None and process.poll() is None:
            os.killpg(process.pid,signal.SIGKILL);process.wait()
        budget.settle(reservation,time.monotonic()-start)


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,default=ROOT/'configs/pseudocube_619_pilot.json')
    parser.add_argument('--through-stage',choices=('A','B'),default='B')
    args=parser.parse_args()
    raw,config=load(args.config)
    manifest=build_manifest()
    build=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
    directory=ROOT/'artifacts/pseudocube-pilot'/build[:16]
    directory.mkdir(parents=True,exist_ok=True)
    durable(directory/'source-manifest.json',manifest)
    durable(directory/'configuration.json',raw)
    durable(directory/'mathematics.json',config.manifest())
    budget=Ledger(ROOT/'artifacts/authority-budget',{'authority':'pseudocube-pilot-619-initial','gpu_limit':600,'pilot_limit':1800},build)
    prior=directory/'pipeline.json'
    if prior.exists():
        previous=json.loads(prior.read_text())
        if previous.get('stage_b',{}).get('status')=='PASS':
            print(json.dumps(dict(status='ALREADY_COMPLETE',receipt=str(prior),budget=budget.audit()['budget'])));return
        if previous.get('stage_b',{}).get('status')=='FAIL':
            raise RuntimeError('RECOVERY_REQUIRED: preserve this failed build; inspect ownership and receipts before retrying')
    report: dict[str,Any]=dict(build=build,platform=platform.platform(),python=sys.version,stage_0=dict(status='PASS',workspace=str(ROOT)),
        stage_a=dict(status='NOT_RUN'),stage_b=dict(status='NOT_RUN'),stage_c='REVIEW_ONLY',production_started=False,
        multi_gpu_started=False,range_extended=False,external_communication=False)
    try:
        report['stage_a']=stage_a(directory)
        durable(directory/'stage-a.json',report['stage_a'])
        if args.through_stage=='B':
            # Reserve the entire remaining Stage-B wall budget across resumes.
            used=sum(float(r['reserved'] if r['state']=='held' else r['charged']) for r in budget.audit()['budget'] if r['kind']=='pilot')
            maximum=float(raw['pilot_budget']['max_total_pilot_wall_seconds'])
            ticket=budget.reserve('pilot',maximum-used,maximum);start=time.monotonic()
            try:report['stage_b']=gpu_stage(directory,args.config.resolve(),raw,budget,maximum-used)
            finally:budget.settle(ticket,time.monotonic()-start)
        report['decision']='NEEDS_OPTIMIZATION' if report['stage_b']['status']=='PASS' else 'BLOCKED'
    except Exception as exc:
        report['error']=repr(exc);report['decision']='BLOCKED'
        if report['stage_a']['status']=='NOT_RUN':report['stage_a']={'status':'FAIL','error':repr(exc)}
        elif report['stage_b']['status']=='NOT_RUN':report['stage_b']={'status':'FAIL','error':repr(exc)}
    finally:
        report['budget']=budget.audit()['budget']
        durable(directory/'pipeline.json',report)
        print(json.dumps(report),flush=True)
    if 'error' in report or report['stage_b']['status']=='FAIL':raise SystemExit(1)


if __name__=='__main__':main()
