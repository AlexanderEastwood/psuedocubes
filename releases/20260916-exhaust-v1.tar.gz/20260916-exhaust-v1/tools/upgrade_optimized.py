#!/usr/bin/env python3
"""Offline, lock-protected activation of a qualified shared-frontier release."""
from __future__ import annotations
import argparse
from contextlib import ExitStack
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pseudocube.accounting import durable
from pseudocube.multi import DEVICES, SharedFrontier, load_multi
from pseudocube.optimized import LEASE_WIDTH, PROFILE, ledger_settings
from tools.audit_multi import snapshot
from tools.run_production import frozen_build


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--state', type=Path, required=True)
    parser.add_argument('--backup', type=Path, required=True)
    parser.add_argument('--qualification', type=Path, required=True)
    parser.add_argument('--resume-after-candidate', action='store_true',
                        help='explicitly authorized continuation of the unsearched remainder')
    args = parser.parse_args()
    state = args.state.resolve()
    build = frozen_build()
    proof = json.loads(args.qualification.read_text())
    if proof['status'] != 'PASS' or proof['build'] != build or proof['production_coverage'] != 0:
        raise ValueError('qualification does not match this release')
    if proof['projected_state_bytes'] >= proof['max_state_bytes']:
        raise ValueError('storage qualification failed')
    if args.resume_after_candidate and proof.get('resume_policy_tests') != 'PASS':
        raise ValueError('candidate continuation requires qualified policy tests')
    multi, raw, math = load_multi(ROOT/'configs/pseudocube_619_multi.json')
    with ExitStack() as locks:
        for owner in DEVICES:
            service = 'pseudocube619-worker@'+owner+'.service'
            result = subprocess.run(['systemctl', '--user', 'is-active', service], capture_output=True, text=True)
            if result.stdout.strip() not in ('inactive', 'failed'):
                raise ValueError('worker service is not stopped: '+owner)
            for path in (Path('/tmp')/('pseudocube-'+owner+'.lock'), state/'workers'/owner/'owner.lock'):
                stream = locks.enter_context(path.open('a'))
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            if subprocess.check_output(['nvidia-smi', '-i', owner, '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip():
                raise ValueError('GPU is occupied: '+owner)
        old_build, old_width, old_profile = ledger_settings(state/'coverage')
        if old_build == build:
            raise ValueError('already upgraded; refusing another transition')
        snapshot(state, args.backup.resolve())
        frontier = SharedFrontier(state/'coverage', dict(multi=multi, production=raw, mathematics=math.manifest()),
                                  old_build, math.B, old_width, DEVICES, profile=old_profile)
        try:
            evidence = dict(qualification_path=str(args.qualification.resolve()),
                qualification_sha256=hashlib.sha256(args.qualification.read_bytes()).hexdigest(),
                backup=str(args.backup.resolve()), exclusive_gpu_and_owner_locks=True, all_services_stopped=True)
            if args.resume_after_candidate:
                evidence['authorization'] = 'Complete the remaining space.'
            cert = frontier.upgrade(build, LEASE_WIDTH, PROFILE, evidence,
                                    resume_after_candidate=args.resume_after_candidate)
            durable(args.backup/'upgrade.json', cert)
            print(json.dumps(dict(status='PASS', boundary=cert['boundary'], build=build)))
        finally:
            frontier.db.close()


if __name__ == '__main__':
    main()
