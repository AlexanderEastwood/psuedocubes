#!/usr/bin/env python3
"""Render the matching parallelism experiment without replacing the pilot baseline."""
from __future__ import annotations
import argparse
import hashlib
from html import escape
import json
from pathlib import Path
import sqlite3
import sys
from typing import Any

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from pseudocube.accounting import durable
from tools.verify_pilot import audit


def generate(directory: Path, output: Path) -> dict[str,Any]:
    directory=directory.resolve();output=output.resolve()
    baseline_audit=audit(directory,ROOT)
    pipeline=json.loads((directory/'pipeline.json').read_text())
    gpu=json.loads((directory/'gpu-results.json').read_text())
    result=json.loads((directory/'parallel-results.json').read_text())
    if result['status']!='PASS':raise ValueError('parallelism gate did not pass')
    base=directory/'parallel-ledger'
    db=sqlite3.connect((base/'coverage.sqlite3').as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
    try:
        if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('corrupt parallel ledger')
        states=[r[0] for r in db.execute('SELECT state FROM work')]
        if states!=['committed']*4:raise ValueError('missing reference scope')
        identity=db.execute("SELECT value FROM meta WHERE key='config'").fetchone()[0]
        validations=list(db.execute('SELECT * FROM validations'))
        if len(validations)!=144:raise ValueError('missing validation replay')
        for row in validations:
            data=(base/row['receipt']).read_bytes();receipt=json.loads(data)
            if row['state']!='verified' or hashlib.sha256(data).hexdigest()!=row['sha'] or receipt['config']!=identity or receipt['attempt']!=row['token'] or receipt['build']!=pipeline['build']:
                raise ValueError('invalid validation receipt')
        for row in db.execute('SELECT * FROM work'):
            data=(base/row['receipt']).read_bytes();receipt=json.loads(data)
            if hashlib.sha256(data).hexdigest()!=row['sha'] or receipt['build']!=pipeline['build']:raise ValueError('invalid reference receipt')
    finally:db.close()
    chosen=[r for r in result['summary'] if r['layout']=='warp' and r['blocks_per_sm']==2]
    charge=sum(float(r['charged'] if r['state']=='closed' else r['reserved']) for r in pipeline['budget'] if r['kind']=='gpu')
    report=dict(status='PASS',source_build=pipeline['build'],evidence_directory=str(directory.relative_to(ROOT)),
                baseline_receipt_audit=baseline_audit,parallel_receipt_audit='PASS',correctness=gpu['correctness'],
                serial_layout_retained=True,default_layout='warp',default_target_blocks_per_sm=2,
                cumulative_gpu_allocation_seconds=charge,previous_pilot_gpu_seconds=9.492926895967685,
                peak_device_pool_bytes=gpu['peak_pool_bytes'],maximum_host_rss_bytes=gpu['maximum_host_rss_bytes'],
                measured_active_warp_occupancy=False,summary=result['summary'],
                counters='All complete output sets, focused candidate counts and per-filter populations agree with the serial reference.',
                full_interval_complete=False,production_started=False,novel_production_coverage=0)
    output.mkdir(parents=True,exist_ok=True);durable(output/'parallelism.json',report)
    table=''.join('<tr>'+''.join(f'<td style="padding:7px;border-bottom:1px solid #ddd">{escape(str(value))}</td>' for value in
        (r['label'],'serial' if r['layout']=='serial' else f"warp / {r['blocks_per_sm']}×SM",r['launch_blocks'],
         f"{r['kernel_ms']:.3f}",f"{r['end_to_end_ms']:.3f}",f"{r['kernel_speedup']:.1f}×",f"{r['end_to_end_speedup']:.2f}×"))+'</tr>' for r in result['summary'])
    p=lambda text:f'<p style="line-height:1.6;margin:16px 0">{text}</p>'
    html='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pseudocube matching parallelism</title><body style="margin:0;background:#f6f4ee;font-family:Georgia,serif;color:#202b2b"><main style="max-width:680px;margin:36px auto;padding:30px;background:white;border-top:5px solid #176d68"><p style="letter-spacing:2px;font-size:12px;color:#176d68">PSEUDOCUBE · MATCHING PARALLELISM</p><h1 style="font-size:34px">Use more of the GPU.</h1>'
    html+=p(f"Implemented a warp-based row partition and made it the default matcher. Across the four bounded pilot scopes, the preselected two-blocks-per-SM target gives <strong>{min(r['kernel_speedup'] for r in chosen):.1f}–{max(r['kernel_speedup'] for r in chosen):.1f}× faster matching kernels</strong> and <strong>{min(r['end_to_end_speedup'] for r in chosen):.2f}–{max(r['end_to_end_speedup'] for r in chosen):.2f}× faster end-to-end tile processing</strong> than the freshly measured serial layout. The serial implementation remains available for A/B validation.")
    html+=p(f"The same tiles now launch {min(r['launch_blocks'] for r in chosen)}–{max(r['launch_blocks'] for r in chosen)} blocks instead of 1–4. Quad's RTX 5080 has 84 SMs. This measures launch geometry, not active-warps occupancy. The launch target is a tuning parameter; rows, tails and rounding determine the actual block count.")
    html+='<h2 style="font-size:23px">What changed</h2>'+p('For each v row, warp lanes process different u positions. Multiple warps partition longer rows into disjoint strides. Every valid position has exactly one owner; the same lower/upper clipping and residual filters remain in force. Counts are summed within each warp before atomic updates, reducing contention. No candidate list is materialized for the Cartesian product.')
    html+='<h2 style="font-size:23px">Measured comparison</h2>'+p('Nine repeats per layout and region, rotating execution order. All runs regenerate the focus windows. Medians below include enumeration, matching, transfer and CPU verification; compilation and durable receipts are separately recorded. Byte tables are held fixed, so the comparison isolates execution layout. The held-out region was not used to change the preselected default.')
    html+='<div style="overflow-x:auto"><table style="font:12px Arial,sans-serif;border-collapse:collapse;width:100%"><tr>'+''.join('<th style="background:#e7f1ef;padding:7px;text-align:left">'+x+'</th>' for x in ('Region','Layout','Blocks','Kernel ms','Tile ms','Kernel gain','Tile gain'))+'</tr>'+table+'</table></div>'
    html+=p('Focus generation limits the end-to-end gain: making matching faster cannot remove enumeration and synchronization costs. These small-tile measurements do not establish production throughput or a full-interval completion time.')
    html+='<h2 style="font-size:23px">Correctness and evidence</h2>'+p(f"The executed CPU suite and {gpu['correctness']['cases']} GPU correctness cases passed, including all three table types and all four layouts on complete small output sets, high-magnitude canaries, exact endpoints, table mutation and overflowing-tile split/replay. The default layout also passed the ordinary 60-execution pilot. The parallel comparison separately recorded four reference receipts and 144 replay receipts. Every compared population and output set matched, and source/receipt audits passed.")
    html+=p(f"Cumulative GPU allocation, including the original pilot and all retries: {charge:.3f}/600 seconds. Peak device pool: {gpu['peak_pool_bytes']/2**20:.1f} MiB; host maximum RSS: {gpu['maximum_host_rss_bytes']/2**20:.1f} MiB. Pool memory excludes driver/context allocations. Register and local-memory metadata are preserved per compiled kernel. No active-warp profiler or compute-sanitizer run is claimed.")
    html+=p('This change is integrated into the bounded pilot, not deployed as a production search. Benchmark repeats add no novel production coverage. Original baseline reports and the original handoff archive remain frozen. Mathematical partition proof and reproduction commands are in the project notes.')
    html+=p('<a href="parallelism.json">Machine-readable comparison</a> · <a href="pseudocube_pilot.html">Original baseline report</a> · <a href="../docs/pseudocube/parallelism.md">Partition proof and commands</a>')
    html+=f'<p style="font:11px monospace;overflow-wrap:anywhere;color:#667">Build {pipeline["build"]}</p></main></body></html>'
    (output/'parallelism.html').write_text(html)
    print(json.dumps(dict(status='PASS',gpu_seconds=charge,default=chosen),indent=2))
    return report


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('directory',type=Path)
    parser.add_argument('--output',type=Path,default=ROOT/'reports');args=parser.parse_args()
    generate(args.directory,args.output)


if __name__=='__main__':main()
