#!/usr/bin/env python3
"""Generate the Stage C review packet from actual bounded-pilot receipts."""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
from fractions import Fraction
import hashlib
from html import escape
import json
from math import prod
from pathlib import Path
from statistics import median
import subprocess
import sys
from typing import Any

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from pseudocube.accounting import durable
from pseudocube.focus import Config,A619,B619
from pseudocube.oracle import primes_upto
from tools.verify_pilot import audit


def generate(directory: Path, output: Path) -> dict[str,Any]:
    directory=directory.resolve();output=output.resolve()
    pipeline=json.loads((directory/'pipeline.json').read_text())
    gpu=json.loads((directory/'gpu-results.json').read_text())
    verification=audit(directory,ROOT)
    records=gpu['measurements']['records'];rows=[]
    focused=float(Fraction(prod(f.count for f in Config(619,10**27,3*10**27,A619,B619).focuses()),A619*B619)*2*10**27)
    qs=primes_upto(619)
    rho=Fraction(2,9)*prod(Fraction(q-1,3*q if q%3==1 else q) for q in qs if q!=3)
    for label in ('lower','middle','upper','held-out'):
        for variant in ('byte','packed','constant'):
            sample=[r for r in records if r['label']==label and r['variant']==variant]
            r=sample[0];wall=median(x['end_to_end_seconds'] for x in sample)
            checkpoint=median(x['checkpoint_seconds'] for x in sample)
            row={k:r[k] for k in ('label','variant','focus_u','focus_v','valid_focused_candidates','launch_blocks','group_survivors','genuine_cubes','noncube_reports')}
            row.update(repeats=len(sample),kernel_ms=1000*median(x['kernel_seconds'] for x in sample),
                       enumeration_ms=1000*median(x['focus_enumeration_seconds'] for x in sample),
                       transfer_ms=1000*median(x['transfer_seconds'] for x in sample),
                       verification_ms=1000*median(x['verification_seconds'] for x in sample),checkpoint_ms=1000*checkpoint,
                       elapsed_ms=1000*wall,min_elapsed_ms=1000*min(x['end_to_end_seconds'] for x in sample),
                       max_elapsed_ms=1000*max(x['end_to_end_seconds'] for x in sample),
                       focused_per_second=r['valid_focused_candidates']/wall,
                       model_years_without_checkpoint=focused*wall/r['valid_focused_candidates']/(365.25*86400),
                       model_years_with_checkpoint=focused*(wall+checkpoint)/r['valid_focused_candidates']/(365.25*86400))
            rows.append(row)
    baseline=[r for r in rows if r['variant']=='byte']
    budget=pipeline['budget']
    seconds={kind:sum(float(r['charged'] if r['state']=='closed' else r['reserved']) for r in budget if r['kind']==kind) for kind in ('gpu','pilot')}
    prime_counts={str(k):sum(q%3==k for q in qs) for k in (0,1,2)}
    primaries=gpu['measurements']['ledger']['committed_results']
    try:head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True,stderr=subprocess.DEVNULL).strip()
    except subprocess.CalledProcessError:head=None
    result=dict(schema_version=1,generated_utc=datetime.now(timezone.utc).isoformat(),decision='NEEDS_OPTIMIZATION',
        workspace=str(ROOT),branch='pseudocube/pilot',source_revision=head,build=pipeline['build'],
        evidence_directory=str(directory.relative_to(ROOT)),gates={k:pipeline[k] for k in ('stage_0','stage_a','stage_b')},
        receipt_audit=verification,independent_cube_count=38322775,primes=len(qs),prime_mod3_counts=prime_counts,
        density=dict(local=float(rho),width_times_local=float(rho*2*10**27),focus=focused/(2*10**27),estimated_focused_candidates=focused,
                     interpretation='Residue-class density only; not an exact finite-interval count or success probability.'),
        resources=dict(gpu_allocation_seconds=seconds['gpu'],stage_b_seconds=seconds['pilot'],
                       gpu_limit_seconds=600,stage_b_limit_seconds=1800,peak_device_pool_bytes=gpu['peak_pool_bytes'],
                       maximum_host_rss_bytes=gpu['maximum_host_rss_bytes'],device_cap_bytes=gpu['device_memory_cap'],
                       output_bytes=sum(p.stat().st_size for p in directory.rglob('*') if p.is_file())),
        measurements=rows,primary_tiles=4,validation_replays=56,
        primary_focused_candidates=sum(r['valid_focused_candidates'] for r in primaries),
        primary_local_survivors=sum(r['local_survivors'] for r in primaries),
        cost_model=dict(baseline_min_years=min(r['model_years_without_checkpoint'] for r in baseline),
                        baseline_max_years=max(r['model_years_without_checkpoint'] for r in baseline),
                        with_checkpoint_min_years=min(r['model_years_with_checkpoint'] for r in baseline),
                        with_checkpoint_max_years=max(r['model_years_with_checkpoint'] for r in baseline),
                        warning='Sensitivity calculation for these small tile shapes at a density-estimated work count. Not a production ETA. Full-range tiling, independent replay and scaling unmeasured.'),
        full_interval_complete=False,production_started=False,multi_gpu_started=False,range_extended=False,external_communication=False)
    output.mkdir(parents=True,exist_ok=True);durable(output/'pseudocube_pilot.json',result)
    t=''.join('<tr>'+''.join(f'<td style="padding:7px;border-bottom:1px solid #ddd">{escape(str(x))}</td>' for x in
        (r['label'],r['variant'],f"{r['kernel_ms']:.3f}",f"{r['elapsed_ms']:.3f}",f"{r['checkpoint_ms']:.3f}",f"{r['focused_per_second']/1e6:.1f}"))+'</tr>' for r in rows)
    cost=result['cost_model'];resources=result['resources']
    p=lambda s:f'<p style="margin:16px 0;line-height:1.6">{s}</p>'
    html='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pseudocube pilot — Stage C review</title><body style="margin:0;background:#f6f4ee;color:#202b2b;font-family:Georgia,serif"><main style="max-width:680px;margin:40px auto;padding:30px;background:white;border-top:5px solid #176d68">'
    html+='<p style="letter-spacing:2px;font-size:12px;color:#176d68">PSEUDOCUBE · SINGLE GPU PILOT · 14 SEPTEMBER 2026</p><h1 style="font-size:34px;line-height:1.1">Correctness passed.<br>Optimize before production.</h1>'
    html+=p(f"Implemented in <code>/Users/alex/psuedocube</code>, branch <code>pseudocube/pilot</code>. Stage 0, CPU Stage A and bounded GPU Stage B passed. The final pilot compared 60 executions of four explicit scopes: four primary receipts and 56 separately recorded validation replays. Their {result['primary_focused_candidates']:,} focused candidates produced {result['primary_local_survivors']} local survivors. This is a pilot result, not exhaustion of (10²⁷, 3×10²⁷].")
    html+='<h2 style="font-size:23px">Independent arithmetic checks</h2>'
    html+=p('Two independent segmented C programs both counted <strong>38,322,775 eligible genuine cubes</strong> in the proposed interval, using 1 MiB segments. These are known structured survivors, not new pseudocubes. CPU tests cover exact roots, all residues of all relevant primes, coefficient-adjusted CRT enumeration, full small output sets, partitions, endpoints, arithmetic limbs and recovery.')
    html+=p('The actual CUDA path passed complete-set comparisons through p=7, 13, 19 and 31; recovered the published p=613 value and high-magnitude genuine cubes; excluded exact lower endpoints; detected a mutated table; and invalidated, split and replayed an overflowing tile. The standalone verifier establishes candidate validity only. Historical minimality below 10²⁷ was not independently rerun.')
    html+='<h2 style="font-size:23px">Measured baseline</h2>'
    html+=p(f"Quad RTX 5080, 84 SMs, UUID <code style='overflow-wrap:anywhere'>{escape(gpu['device_uuid'])}</code>. CuPy {gpu['cupy']}, NumPy {gpu['numpy']}, CUDA runtime {gpu['cuda_runtime']}; actual compilation uses NVRTC with C++17 and explicit 64-bit limbs. Five repeats per variant and scope; medians below. Elapsed includes focus enumeration, kernel, transfers and host checking; checkpoint time is separate. Compilation and context setup are included in allocation time, outside these steady-state timings.")
    html+='<div style="overflow-x:auto"><table style="border-collapse:collapse;font-size:13px;width:100%;font-family:Arial,sans-serif"><thead><tr>'+''.join('<th style="padding:7px;text-align:left;background:#e7f1ef">'+s+'</th>' for s in ('Region','Table','Kernel ms','Elapsed ms','Receipt ms','M focused/s'))+'</tr></thead><tbody>'+t+'</tbody></table></div>'
    html+=p('These tiny tile shapes launch only 1–4 matching blocks on 84 SMs. This is observed launch geometry, not measured active-warps occupancy. Profile larger bounded tiles or distribute each u/v tile over more blocks next, preserving complete output sets. Byte, packed global and packed constant lookup variants do not establish a large end-to-end improvement here. Focus preparation also consumes a material fraction of each short tile. Keep the byte baseline until a repeatable end-to-end gain is demonstrated.')
    html+=p(f"GPU allocation across all attempts: <strong>{seconds['gpu']:.3f} / 600 seconds</strong>; aggregate Stage B: {seconds['pilot']:.3f} / 1,800 seconds. Peak CuPy pool {resources['peak_device_pool_bytes']/2**20:.1f} MiB; host process maximum RSS {resources['maximum_host_rss_bytes']/2**20:.1f} MiB. Pool figures exclude driver/context memory. The first attempt failed a bounded-period guard before benchmarking; its 1.513 seconds remain charged and its evidence is preserved. Register/local-memory metadata are recorded per compiled kernel. nvcc, compute-sanitizer and active-warp profiling were unavailable/not run; none is marked passed.")
    html+='<h2 style="font-size:23px">Work estimate and practical limit</h2>'
    html+=p(f"Re-derived local density: {float(rho):.11g}; width × density: {float(rho*2*10**27):.6f}. This is neither a success probability nor a prediction of all finite-interval survivors. Focus density: {focused/(2*10**27):.11g}, giving about {focused:.6g} focused candidates. Applying the measured byte-table tile rates gives a sensitivity range of <strong>{cost['baseline_min_years']:.1f}–{cost['baseline_max_years']:.1f} GPU-years</strong> before checkpoint overhead, or {cost['with_checkpoint_min_years']:.1f}–{cost['with_checkpoint_max_years']:.1f} with the measured per-tile receipts. This is a model of the current small tile shapes, not a production ETA. Full-size scheduling, verification redundancy and scaling have not been measured.")
    html+='<h2 style="font-size:23px">Coverage, provenance and handoff</h2>'
    html+=p('Canonical x=uB−vA with 0≤v&lt;B gives unique coordinates; coefficient adjustments and exact inequalities are documented. The SQLite ledger binds configuration, source build, expected scopes and attempt identities. Durable receipts precede commit; replay records never add coverage; split parents are excluded; stale ownership, output corruption, changed configuration and duplicate work are tested. The read-only handoff audit passed. Matching counts and valid survivors do not prove noncube completeness.')
    html+=p('Historical source: <a href="https://arxiv.org/pdf/1001.3316v2">Sorenson, arXiv:1001.3316v2</a>, definition/new values PDF page 2, full Table 2 page 5, focus split section 4.1 page 7. The exact PDF hash, old source hashes, formulas, counter definitions, commands and raw evidence are included. No claim is made that no newer result exists.')
    html+=p('Stage C decision: <strong>NEEDS_OPTIMIZATION</strong>. The next reviewed experiment should improve matching parallelism and bounded tile sizing, then compare end-to-end time against this preserved baseline. Before production, settle the historical-bound evidence and independent replay standard; budget that verification separately. Draft questions for Jon are in the verification policy. No production search, multiple-GPU run, range extension or external message was performed.')
    html+=p('<a href="pseudocube_pilot.json">Machine-readable results</a> · <a href="../README.md">Reproduction commands</a> · <a href="../docs/pseudocube/preflight.md">Reuse audit</a> · <a href="../docs/pseudocube/math.md">Mathematical contract</a>')
    html+=f'<p style="font:11px monospace;overflow-wrap:anywhere;color:#667">Build {pipeline["build"]}<br>Source revision {head or "not yet committed"}</p></main></body></html>'
    (output/'pseudocube_pilot.html').write_text(html)
    (output/'pseudocube_pilot.md').write_text(f'''# Pseudocube pilot — NEEDS_OPTIMIZATION

The styled report is `pseudocube_pilot.html`; the complete machine-readable report is `pseudocube_pilot.json`.
Workspace: {ROOT}; branch: pseudocube/pilot; source revision: {head}; build: {pipeline['build']}.
Stage 0/A/B: PASS. Read-only receipt/source audit: PASS. Primary tiles: 4; separate validation replays: 56.
Both independent cube counters: 38,322,775. Primary focused candidates: {result['primary_focused_candidates']:,}.
GPU allocation across all attempts: {seconds['gpu']:.6f}/600 seconds. Stage B: {seconds['pilot']:.6f}/1800 seconds.
Raw evidence: {directory.relative_to(ROOT)}. Commands and exit codes are embedded in the JSON.
No full-interval coverage, production, multi-GPU run, range extension or external communication.
Next: improve matching parallelism / bounded tile sizing, then review the verification policy.
''')
    return result


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('directory',type=Path)
    parser.add_argument('--output',type=Path,default=ROOT/'reports');args=parser.parse_args()
    result=generate(args.directory,args.output)
    print(json.dumps({k:result[k] for k in ('decision','build','resources','cost_model')}))


if __name__=='__main__':main()
