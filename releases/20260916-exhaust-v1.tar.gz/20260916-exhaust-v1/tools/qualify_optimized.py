#!/usr/bin/env python3
"""Isolated full-lease equivalence, recovery and four-GPU durable canary."""
from __future__ import annotations
import argparse
import gzip
import json
import multiprocessing as mp
import os
from pathlib import Path
import sys
import time
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pseudocube.accounting import digest, durable
from pseudocube.batch_experiment import MaskedMatcher, compare, prepare
from pseudocube.gpu import GPUFocus, Matcher, Runtime
from pseudocube.multi import DEVICES, SharedFrontier
from pseudocube.optimized import Accumulator, BATCH_WIDTH, LEASE_WIDTH, PROFILE, allocated_bytes, compute_lease
from tools.batch_window_experiment import config, gpu_lock
from tools.run_production import compute_batch, frozen_build

BASE = dict(cursor='0', commits='0', candidates='0', cubes='0', subtiles='0', campaign_state='searching')


def signature(row: dict[str, Any]) -> str:
    return digest({k: v for k, v in row.items() if not k.endswith('_seconds')})


def connection(path: Path, build: str, end: int, baseline: bool = False) -> SharedFrontier:
    return SharedFrontier(path, dict(purpose='optimized-production-qualification', mathematics=config().manifest()),
        build, end, LEASE_WIDTH, DEVICES, BASE if baseline else None, PROFILE)


def equivalence(output: Path, build: str) -> dict[str, Any]:
    lock = gpu_lock(DEVICES[0])
    runtime = Runtime(time.monotonic()+180, 8*1024**3)
    c = config()
    af, bf = (GPUFocus(runtime, f) for f in c.focuses())
    reference, masked = Matcher(runtime, c), MaskedMatcher(runtime, c)
    acc = Accumulator(0, LEASE_WIDTH)
    started = time.monotonic()
    for first in range(0, LEASE_WIDTH, BATCH_WIDTH):
        acc.add(first, first+BATCH_WIDTH, compute_batch(reference, af, bf, first, first+BATCH_WIDTH, PROFILE['tile_width']))
    baseline = acc.finish(time.monotonic()-started)
    actual = compute_lease(masked, af, bf, 0, LEASE_WIDTH)
    if signature(baseline) != signature(actual):
        raise ArithmeticError('full 256-batch lease/reference mismatch')
    cases = []
    for first, end in ((246112000000000, 246112000000000+BATCH_WIDTH),
                       (c.B//2, c.B//2+BATCH_WIDTH), (c.B-100000001, c.B)):
        old = compute_batch(reference, af, bf, first, end, PROFILE['tile_width'])
        new = masked.run(prepare(runtime, c, af, bf, first, end, PROFILE['tile_width']))
        compare(old, new)
        cases.append(dict(first=str(first), end=str(end), status='PASS'))
    result = dict(status='PASS', build=build, full_lease_reference=baseline,
                  full_lease_optimized=actual, boundary_cases=cases, peak_device_bytes=runtime.peak_device)
    durable(output/'equivalence.json', result)
    lock.close()
    return result


def fault_worker(path: str, build: str, after_commit: bool) -> None:
    lock = gpu_lock(DEVICES[0])
    runtime = Runtime(time.monotonic()+90, 8*1024**3)
    c = config(); af, bf = (GPUFocus(runtime, f) for f in c.focuses())
    matcher = MaskedMatcher(runtime, c)
    db = connection(Path(path), build, 2*LEASE_WIDTH)
    db.recover(DEVICES[0], 'exclusive GPU lock; previous isolated process exited')
    job = db.next_batch(DEVICES[0]); assert job
    result = compute_lease(matcher, af, bf, job[2], job[3])
    durable(Path(path).parent/('computed-committed.json' if after_commit else 'computed-uncommitted.json'),
            dict(first=str(job[2]), end=str(job[3]), signature=signature(result), token=job[1]))
    if after_commit:
        db.complete(DEVICES[0], job, result)
    # This exits only this harness-owned isolated child, never a production service.
    os._exit(92)


def fleet_worker(path: str, build: str, device: str, end: int, ready: Any, start: Any, results: Any) -> None:
    try:
        lock = gpu_lock(device)
        runtime = Runtime(time.monotonic()+180, 8*1024**3)
        c = config(); af, bf = (GPUFocus(runtime, f) for f in c.focuses())
        matcher = MaskedMatcher(runtime, c)
        masked = matcher.run(prepare(runtime, c, af, bf, 0, BATCH_WIDTH, PROFILE['tile_width']))
        reference = compute_batch(Matcher(runtime, c), af, bf, 0, BATCH_WIDTH, PROFILE['tile_width'])
        compare(reference, masked)
        db = connection(Path(path), build, end)
        ready.put(device)
        if not start.wait(90): raise TimeoutError('canary start barrier')
        started = time.monotonic(); jobs = 0
        while True:
            job = db.next_batch(device)
            if job is None: break
            row = compute_lease(matcher, af, bf, job[2], job[3])
            db.complete(device, job, row); jobs += 1
        results.put(dict(status='PASS', device=device, jobs=jobs, seconds=time.monotonic()-started,
                         peak_device_bytes=runtime.peak_device))
        db.db.close(); lock.close()
    except BaseException as exc:
        results.put(dict(status='FAIL', device=device, error=repr(exc)))
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--equivalence-only', action='store_true')
    args = parser.parse_args()
    output = args.output.resolve(); output.mkdir(parents=True, exist_ok=False)
    build = frozen_build()
    if args.equivalence_only:
        equivalence(output, build)
        return
    import subprocess
    subprocess.run([sys.executable, str(Path(__file__).resolve()), '--output', str(output/'single'), '--equivalence-only'], check=True)
    ctx = mp.get_context('spawn')
    recovery = output/'recovery'/'coverage'
    connection(recovery, build, 2*LEASE_WIDTH, True).db.close()
    for committed in (False, True):
        child = ctx.Process(target=fault_worker, args=(str(recovery), build, committed))
        child.start(); child.join(90)
        if child.is_alive() or child.exitcode != 92:
            raise RuntimeError('isolated GPU recovery probe failed')
    a = json.loads((recovery.parent/'computed-uncommitted.json').read_text())
    b = json.loads((recovery.parent/'computed-committed.json').read_text())
    if a['signature'] != b['signature'] or a['first'] != b['first'] or a['token'] == b['token']:
        raise ArithmeticError('recovered range/output mismatch')
    db = connection(recovery, build, 2*LEASE_WIDTH)
    if db.recover(DEVICES[0], 'isolated child exited after commit') != 0:
        raise ValueError('committed range was incorrectly recovered')
    job = db.next_batch(DEVICES[0]); assert job and job[2] == LEASE_WIDTH
    recovery_audit = db.audit_shared(); db.db.close()
    end = 32*LEASE_WIDTH + 200_000_001
    path = output/'fleet'/'coverage'
    connection(path, build, end, True).db.close()
    ready, results, start = ctx.Queue(), ctx.Queue(), ctx.Event()
    children = [ctx.Process(target=fleet_worker, args=(str(path), build, device, end, ready, start, results)) for device in DEVICES]
    for child in children: child.start()
    devices = [ready.get(timeout=90) for _ in DEVICES]
    if set(devices) != set(DEVICES): raise ValueError('GPU canary allocation mismatch')
    started = time.monotonic(); start.set()
    rows = [results.get(timeout=180) for _ in DEVICES]
    seconds = time.monotonic()-started
    for child in children:
        child.join(30)
        if child.is_alive() or child.exitcode != 0: raise RuntimeError('GPU fleet child failed')
    if any(row['status'] != 'PASS' for row in rows): raise RuntimeError(str(rows))
    db = connection(path, build, end)
    audit = db.audit_shared()
    sizes = [r[0] for r in db.db.execute('SELECT length(data) FROM receipt_blobs')]
    db.db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
    state_size = allocated_bytes(path)
    db.db.close()
    # Conservative: maximum receipt plus 4 KiB row/index allowance, doubled; retain old evidence.
    projected = int((config().B+LEASE_WIDTH-1)//LEASE_WIDTH) * (max(sizes)+4096)*2 + 512*1024**2
    report = dict(status='PASS', build=build, production_coverage=0, profile=PROFILE,
        equivalence='single/equivalence.json', recovery=recovery_audit, recovery_same_range_and_output=True,
        audit=audit, workers=rows, seconds=seconds, candidates_per_second=audit['totals']['candidates']/seconds,
        receipt_bytes=dict(min=min(sizes), max=max(sizes), mean=sum(sizes)/len(sizes)),
        canary_state_bytes=state_size, projected_state_bytes=projected, max_state_bytes=8*1024**3)
    if not audit['full_interval_complete'] or projected >= report['max_state_bytes']:
        raise ValueError('coverage or full-domain storage qualification failed: '+json.dumps(report))
    durable(output/'qualification.json', report)
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
