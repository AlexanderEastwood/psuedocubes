#!/usr/bin/env python3
"""One persistent GPU worker attached to the shared, disjoint production frontier."""
from __future__ import annotations
import argparse
import fcntl
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pseudocube.accounting import durable
from pseudocube.gpu import Runtime, GPUFocus
from pseudocube.batch_experiment import MaskedMatcher
from pseudocube.optimized import PROFILE, LEASE_WIDTH, allocated_bytes, compute_lease
from pseudocube.multi import DEVICES, SharedFrontier, load_multi
from tools.run_production import frozen_build, notify, smoke

STOP = False


def stopping(signum: int, frame: Any) -> None:
    global STOP
    STOP = True


def status(directory: Path, frontier: SharedFrontier, owner: str, runtime: Runtime, phase: str, **extra: Any) -> None:
    state = frontier.state()
    state.pop('baseline', None)
    totals = dict(frontier.db.execute('SELECT * FROM worker_totals WHERE owner=?', (owner,)).fetchone())
    row = dict(phase=phase, pid=os.getpid(), updated_unix=time.time(), device_uuid=owner,
               frontier=state, worker=totals, peak_device_pool_bytes=runtime.peak_device, **extra)
    durable(directory / 'status.json', row)
    print(json.dumps(row, separators=(',', ':')), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=ROOT / 'configs/pseudocube_619_multi.json')
    parser.add_argument('--state', type=Path, required=True)
    parser.add_argument('--device', choices=DEVICES, required=True)
    parser.add_argument('--smoke', action='store_true', help='isolated validation, no production coverage')
    args = parser.parse_args()
    multi, raw, math = load_multi(args.config)
    build = frozen_build()
    if os.environ.get('CUDA_VISIBLE_DEVICES') != args.device:
        raise ValueError('worker must see exactly its assigned device')
    directory = args.state.resolve()
    worker = directory / 'workers' / args.device
    worker.mkdir(parents=True, exist_ok=True)
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, stopping)
    with (Path('/tmp') / ('pseudocube-' + args.device + '.lock')).open('a') as gpu_lock, (worker / 'owner.lock').open('a') as state_lock:
        fcntl.flock(gpu_lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        fcntl.flock(state_lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        occupied = subprocess.check_output(['nvidia-smi', '-i', args.device, '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
        if occupied:
            raise RuntimeError('assigned GPU is occupied')
        runtime = Runtime(time.monotonic() + 90 if args.smoke else float('inf'), raw['max_device_bytes'], raw['max_device_fraction'])
        if runtime.cp.cuda.runtime.getDeviceCount() != 1:
            raise RuntimeError('each worker requires one visible device')
        af, bf = (GPUFocus(runtime, f) for f in math.focuses())
        if args.smoke:
            smoke(runtime, worker, math, af, bf, build)
            return
        frontier = SharedFrontier(directory / 'coverage', dict(multi=multi, production=raw, mathematics=math.manifest()),
                                  build, math.B, LEASE_WIDTH, DEVICES, profile=PROFILE)
        frontier.validate_owner_receipt(args.device)
        recovered = frontier.recover(args.device, 'Exclusive GPU and per-device state locks held by PID ' + str(os.getpid()))
        matcher = MaskedMatcher(runtime, math)
        durable(worker / 'release.json', dict(build=build, source=str(ROOT), device_uuid=args.device, configuration=multi))
        status(worker, frontier, args.device, runtime, 'running', recovered_attempts=recovered)
        notify('READY=1\nSTATUS=Searching pseudocube p=619 with shared range ownership')
        last_report = last_resources = 0.0
        try:
            while not STOP:
                now = time.monotonic()
                if now - last_resources > 30:
                    used = allocated_bytes(directory)
                    if used >= raw['max_state_bytes'] or shutil.disk_usage(directory).free < raw['min_free_disk_bytes']:
                        raise MemoryError('production storage guard reached')
                    if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024 > raw['max_host_bytes']:
                        raise MemoryError('host memory guard reached')
                    last_resources = now
                job = frontier.next_batch(args.device)
                if job is None:
                    if frontier.state()['campaign_state'] != 'searching':
                        break
                    notify('WATCHDOG=1\nSTATUS=All remaining ranges reserved; awaiting shared completion')
                    time.sleep(0.5)
                    continue
                try:
                    result = compute_lease(matcher, af, bf, job[2], job[3], lambda: notify('WATCHDOG=1'))
                    frontier.complete(args.device, job, result)
                except Exception as exc:
                    frontier.fail_lease(args.device, job, repr(exc))
                    raise
                if now - last_report > 15 or result['cpu_confirmed_hits']:
                    status(worker, frontier, args.device, runtime, 'running', last_batch_seconds=result['elapsed_seconds'])
                    last_report = now
            status(worker, frontier, args.device, runtime, 'stopped' if STOP else frontier.state()['campaign_state'])
        except Exception as exc:
            status(worker, frontier, args.device, runtime, 'paused-error', error=repr(exc))
            raise
        finally:
            frontier.db.close()


if __name__ == '__main__':
    try:
        main()
    except (MemoryError, ArithmeticError, ValueError, RuntimeError) as exc:
        print(json.dumps(dict(status='STOPPED_FOR_REVIEW', error=repr(exc))), flush=True)
        raise SystemExit(2)
    except BlockingIOError as exc:
        print(json.dumps(dict(status='ALLOCATION_BUSY', error=repr(exc))), flush=True)
        raise SystemExit(4)
