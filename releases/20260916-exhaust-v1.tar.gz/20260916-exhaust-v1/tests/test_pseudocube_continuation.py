from __future__ import annotations
import json
import multiprocessing
import os
from pathlib import Path
import tempfile
from typing import Any
import unittest

from pseudocube.multi import SharedFrontier
from tests.test_pseudocube_multi import BASE, OWNERS, receipt

PROFILE: dict[str, Any] = dict(stop_on_candidate=False, receipt_storage='sqlite-gzip')
EVIDENCE: dict[str, Any] = dict(authorization='Complete the remaining space.',
    exclusive_gpu_and_owner_locks=True, all_services_stopped=True, tests='isolated continuation controls')


def connect(path: Path, build: str = 'old', initial: bool = False) -> SharedFrontier:
    return SharedFrontier(path, {'continuation_test': True}, build, 33, 10, OWNERS,
                          BASE if initial else None, PROFILE if build == 'new' else None)


def stopped(path: Path) -> SharedFrontier:
    db = connect(path, initial=True)
    job = db.next_batch('a'); assert job
    db.complete('a', job, receipt(*job[2:], hit=True))
    return db


def crash_in_upgrade(path: str) -> None:
    db = connect(Path(path))
    db.db.create_function('isolated_exit', 0, lambda: os._exit(92))
    db.db.execute('CREATE TEMP TRIGGER interrupt_upgrade AFTER INSERT ON upgrades BEGIN SELECT isolated_exit(); END')
    db.upgrade('new', 10, PROFILE, EVIDENCE, resume_after_candidate=True)


class ContinuationTests(unittest.TestCase):
    def test_continue_preserves_candidate_and_exhausts_out_of_order_tail(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp); old=stopped(path)
            before=old.state()
            old_row=dict(old.db.execute('SELECT * FROM leases').fetchone())
            old_bytes=(path/old_row['receipt']).read_bytes()
            candidates=list(map(tuple,old.db.execute('SELECT * FROM candidates')))
            cert=old.upgrade('new',10,PROFILE,EVIDENCE,resume_after_candidate=True)
            self.assertEqual(cert['boundary'],'10')
            self.assertEqual(cert['before'],before)
            self.assertEqual(cert['authorization'],EVIDENCE['authorization'])
            with self.assertRaises(ValueError): old.next_batch('b')
            old.db.close()
            db=connect(path,'new')
            self.assertEqual(list(map(tuple,db.db.execute('SELECT * FROM candidates'))),candidates)
            self.assertEqual((path/old_row['receipt']).read_bytes(),old_bytes)
            jobs=[db.next_batch(owner) for owner in OWNERS[:3]]
            self.assertIsNone(db.next_batch('d'))
            a,b,c=jobs; assert a and b and c
            self.assertEqual([j[2:] for j in jobs if j],[(10,20),(20,30),(30,33)])
            another=receipt(*b[2:],hit=True);another['cpu_confirmed_hits'][0]['n']='another-test-only-witness'
            db.complete('b',b,another)
            db.complete('c',c,receipt(*c[2:],hit=True))
            self.assertEqual(db.state()['campaign_state'],'searching')
            self.assertEqual(db.state()['cursor'],'10')
            db.db.close();db=connect(path,'new')
            self.assertEqual(db.recover('a','isolated owner stopped'),1)
            retry=db.next_batch('a');assert retry
            self.assertEqual(retry[2:],a[2:])
            with self.assertRaises(ValueError):db.complete('a',a,receipt(*a[2:]))
            db.complete('a',retry,receipt(*retry[2:],hit=True))
            self.assertEqual(db.state()['campaign_state'],'complete')
            self.assertEqual(db.db.execute('SELECT count(*) FROM candidates').fetchone()[0],2)
            checked=db.audit_shared()
            self.assertTrue(checked['full_interval_complete'])
            self.assertEqual(checked['totals']['commits'],4)
            self.assertFalse(checked['unfinished_leases'])
            self.assertIsNone(db.next_batch('d'));db.db.close()

    def test_requires_authority_and_explicit_continue_policy(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db=stopped(Path(tmp));before=db.state()
            for profile,evidence,flag in ((PROFILE,EVIDENCE,False),({},EVIDENCE,True),
                (PROFILE,dict(EVIDENCE,authorization=''),True),
                (PROFILE,dict(EVIDENCE,all_services_stopped=False),True),
                (dict(PROFILE,stop_on_candidate='false'),EVIDENCE,True)):
                with self.assertRaises(ValueError):
                    db.upgrade('new',10,profile,evidence,resume_after_candidate=flag)
                self.assertEqual(db.state(),before)
                self.assertEqual(db.db.execute('SELECT count(*) FROM upgrades').fetchone()[0],0)
            db.db.close()

    def test_unfinished_owned_lease_prevents_resume(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db=connect(Path(tmp),initial=True)
            a,b=db.next_batch('a'),db.next_batch('b');assert a and b
            db.complete('a',a,receipt(*a[2:],hit=True))
            with self.assertRaises(ValueError):db.upgrade('new',10,PROFILE,EVIDENCE,resume_after_candidate=True)
            self.assertEqual(db.state()['active_build'],'old');db.db.close()

    def test_interrupted_transition_rolls_back_and_can_be_retried(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp);db=stopped(path);before=db.state();db.db.close()
            child=multiprocessing.get_context('spawn').Process(target=crash_in_upgrade,args=(tmp,))
            child.start();child.join(20)
            self.assertFalse(child.is_alive());self.assertEqual(child.exitcode,92)
            db=connect(path)
            self.assertEqual(db.state(),before)
            self.assertEqual(db.db.execute('SELECT count(*) FROM upgrades').fetchone()[0],0)
            db.upgrade('new',10,PROFILE,EVIDENCE,resume_after_candidate=True);db.db.close()
            db=connect(path,'new')
            self.assertFalse(json.loads(db.state()['runtime_profile'])['stop_on_candidate'])
            job=db.next_batch('b');assert job
            self.assertEqual(job[2:],(10,20));db.db.close()


if __name__=='__main__':unittest.main()
